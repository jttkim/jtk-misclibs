#ifndef H_GENOMEIN
#define H_GENOMEIN

#define MAX_SLEN 256

#ifdef MEMDEBUG
#  include "memdebug.h"
#endif

#include "genomelib.h"

#endif

