#include <iostream.h>

extern "C" {

#include <fstream.h>

}


int main(int argc, char *argv[])
{
  cout << "Hi world" << endl;
  return (0);
}

